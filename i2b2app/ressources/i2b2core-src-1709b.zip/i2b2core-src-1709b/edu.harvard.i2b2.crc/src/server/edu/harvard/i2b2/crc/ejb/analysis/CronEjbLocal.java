package edu.harvard.i2b2.crc.ejb.analysis;


public interface CronEjbLocal {
	public void start();

}
